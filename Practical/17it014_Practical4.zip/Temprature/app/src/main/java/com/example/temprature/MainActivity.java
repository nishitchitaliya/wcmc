package com.example.temprature;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {
    Button btn_cfk,btn_fkc, btn_kfc;
    EditText et_f, et_c, et_k;
    RadioButton rb_c, rb_f, rb_k;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_cfk = findViewById(R.id.btn_cfk);


        btn_fkc = findViewById(R.id.btn_fkc);

        btn_kfc = findViewById(R.id.btn_kfc);


        et_f = findViewById(R.id.et_f);
        et_c = findViewById(R.id.et_c);
        et_k=findViewById(R.id.et_k);

        rb_c = findViewById(R.id.rb_c);
        rb_f = findViewById(R.id.rb_f);
        rb_k = findViewById(R.id.rb_k);

        btn_cfk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float c = Float.parseFloat(et_c.getText().toString());
                float f = (c*(float) 9/5)+32;
                et_f.setText(""+f);
                float k = c+ (float) 273.15;
                et_k.setText(""+k);
            }
        });




        btn_fkc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float f = Float.parseFloat(et_f.getText().toString());
                float k = (f-32)*((float)5/9)+ (float)273.15;
                et_k.setText(""+k);
                float c = (f-32)*((float)5/9);
                et_c.setText(""+c);
            }
        });

        btn_kfc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float k = Float.parseFloat(et_k.getText().toString());
                float f = (k-(float)273.15)*((float)9/5)+32;
                et_f.setText(""+f);
                float c = k-(float)273.15;
                et_c.setText(""+c);
            }
        });

    }
}
