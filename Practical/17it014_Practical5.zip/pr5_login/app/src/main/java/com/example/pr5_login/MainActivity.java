package com.example.pr5_login;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.CountDownTimer;


public class MainActivity extends Activity  {
    Button b1,b2;
    EditText ed1,ed2;

    TextView tx2,tx4;
    int counter = 3;
    private AlphaAnimation buttonClick= new AlphaAnimation(0.2F,1.0F);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        b1=(Button)findViewById(R.id.button);
        ed1=(EditText)findViewById(R.id.editText1);
        ed2=(EditText)findViewById(R.id.editText2);

        b2=(Button)findViewById(R.id.button2);

        tx2=(TextView)findViewById(R.id.textView4);


        b1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                buttonClick.setDuration(100);
                buttonClick.setStartOffset(75);
                buttonClick.setFillAfter(true);
                v.startAnimation(buttonClick);
                if(ed1.getText().toString().equals("Raj") &&

                        ed2.getText().toString().equals("raj")) {
                    Toast.makeText(getApplicationContext(), "Authentication Successful",Toast.LENGTH_SHORT).show();
                    tx2.setVisibility(View.VISIBLE);
                    tx2.setBackgroundColor(Color.GREEN);
                    tx2.setText("Login Successful");
                }
                else{
                    counter--;

                    Toast.makeText(getApplicationContext(), "Attempt left:"+counter,Toast.LENGTH_SHORT).show();
                    ed2.setText(null);
                    tx2.setVisibility(View.VISIBLE);
                    tx2.setBackgroundColor(Color.RED);
                    tx2.setText("Error:Username or Password is incorrect." +
                            " Try Agian");
                    if (counter == 0) {
                        counter=3;
                        new CountDownTimer(15000, 1000) {

                            public void onTick(long millisUntilFinished) {
                                ed1.setText(null);ed1.setEnabled(false);
                                ed2.setText(null);ed2.setEnabled(false);
                                b1.setEnabled(false);
                                b1.setBackgroundColor(Color.argb(150,103,58,183));
                                b1.setText( millisUntilFinished / 1000+"s");
                                tx2.setText("You have entered wrong credentials 3 times,Try after 15s.");
                            }

                            public void onFinish() {
                                ed2.setEnabled(true);
                                ed1.setEnabled(true);
                                ed1.requestFocus();
                                b1.setEnabled(true);
                                b1.setText("LOGIN");
                                b1.setBackgroundColor(Color.rgb(103,58,183));
                                tx2.setBackgroundColor(Color.YELLOW);
                                tx2.setText("Give it another shot");
                            }
                        }.start();

                    }
                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                buttonClick.setDuration(100);
                buttonClick.setStartOffset(75);
                buttonClick.setFillAfter(true);
                v.startAnimation(buttonClick);

            }
        });
    }



}
